<?php

$koneksi = mysqli_connect(
    "localhost",
    "root",
    "",
    "dbmahasiswa"
);

if(!$koneksi){
    die("Koneksi gagal");
}

?>