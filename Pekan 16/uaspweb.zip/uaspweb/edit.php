<?php
include 'config/koneksi.php';

$id = $_GET['id'];

$data = mysqli_query($koneksi,"SELECT * FROM mahasiswa WHERE id='$id'");
$d = mysqli_fetch_array($data);

if(isset($_POST['update'])){

    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $prodi = $_POST['prodi'];
    $alamat = $_POST['alamat'];

    mysqli_query($koneksi,"UPDATE mahasiswa SET
        nim='$nim',
        nama='$nama',
        prodi='$prodi',
        alamat='$alamat'
        WHERE id='$id'
    ");

    header("Location: daftar.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Data</title>
</head>
<body>

<h1>Edit Data Mahasiswa</h1>

<form method="POST">

NIM <br>
<input type="text" name="nim" value="<?php echo $d['nim']; ?>">
<br><br>

Nama <br>
<input type="text" name="nama" value="<?php echo $d['nama']; ?>">
<br><br>

Prodi <br>
<input type="text" name="prodi" value="<?php echo $d['prodi']; ?>">
<br><br>

Alamat <br>
<input type="text" name="alamat" value="<?php echo $d['alamat']; ?>">
<br><br>

<button type="submit" name="update">
Update
</button>

</form>

</body>
</html>