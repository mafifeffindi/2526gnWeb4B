<?php
include 'config/koneksi.php';

if(isset($_POST['simpan'])){

    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $prodi = $_POST['prodi'];
    $alamat = $_POST['alamat'];

    mysqli_query($koneksi,
    "INSERT INTO mahasiswa(nim,nama,prodi,alamat)
    VALUES('$nim','$nama','$prodi','$alamat')");

    echo "Data berhasil disimpan";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Data</title>
</head>
<body>

<h1>Tambah Data Mahasiswa</h1>

<a href="index.php">Home</a>

<hr>

<form method="POST">

NIM <br>
<input type="text" name="nim">
<br><br>

Nama <br>
<input type="text" name="nama">
<br><br>

Prodi <br>
<input type="text" name="prodi">
<br><br>

Alamat <br>
<input type="text" name="alamat">
<br><br>

<button type="submit" name="simpan">
Simpan
</button>

</form>

</body>
</html>