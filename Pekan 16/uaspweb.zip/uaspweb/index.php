<!DOCTYPE html>
<html>
<head>
    <title>Sistem Pendataan Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">

    <h1>Sistem Pendataan Mahasiswa</h1>

    <hr>

    <nav>
        <a href="index.php">Home</a>
        <a href="tambah.php">Tambah Data</a>
        <a href="daftar.php">Daftar Data</a>
    </nav>

    <hr>

    <div class="card">
        <h2>Selamat Datang</h2>
        <p>
            Website ini digunakan untuk mengelola data mahasiswa secara
            cepat, akurat, dan terstruktur.
        </p>
    </div>

</div>

</body>
</html>