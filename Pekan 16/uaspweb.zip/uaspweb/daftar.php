<?php
include "config/koneksi.php";

$data = mysqli_query($koneksi,"SELECT * FROM mahasiswa");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Mahasiswa</title>
</head>
<body>

<h2>Daftar Mahasiswa</h2>

<a href="index.php">Home</a>
<br><br>

<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>NIM</th>
        <th>Nama</th>
        <th>Prodi</th>
        <th>Alamat</th>
        <th>aksi</th>
    </tr>

    <?php while($d = mysqli_fetch_array($data)){ ?>
    <tr>
        <td><?php echo $d['id']; ?></td>
        <td><?php echo $d['nim']; ?></td>
        <td><?php echo $d['nama']; ?></td>
        <td><?php echo $d['prodi']; ?></td>
        <td><?php echo $d['alamat']; ?></td>
        <td>
    <a href="edit.php?id=<?php echo $d['id']; ?>">
        Edit
    </a>

    |

    <a href="hapus.php?id=<?php echo $d['id']; ?>">
        Hapus
    </a>
</td>
    </tr>
    <?php } ?>

</table>

</body>
</html>