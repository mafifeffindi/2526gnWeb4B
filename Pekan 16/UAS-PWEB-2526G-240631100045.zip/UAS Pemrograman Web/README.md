## Identitas

Nama                : Muhammad Al-Rhosit
NIM                 : 240631100045
Judul Aplikasi      : Catatan Keuangan
Deskripsi Singkat   : Aplikasi ini merupakan aplikasi pencatatan keuangan dengan fitur tambah, edit, dan juga hapus data.
Screenshot Aplikasi : ![alt text](image.png)

## Struktur Database

| Kolom | Tipe Data | Keterangan |

| id | INT | Primary Key, Auto Increment (ID unik transaksi) |
| tanggal | DATE | Tanggal transaksi terjadi |
| kategori | VARCHAR(100) | Kategori pengeluaran/pemasukan |
| tipe | ENUM | Membatasi nilai hanya 'pemasukan' atau 'pengeluaran' |
| jumlah | DECIMAL(12,2) | Angka presisi tinggi untuk nominal uang |
| keterangan | TEXT | Catatan tambahan (opsional) |
| dibuat_pada | TIMESTAMP | Auto-timestamp saat data pertama dibuat |

## Halaman

- `index.php` - Beranda dan ringkasan saldo.
- `tambah.php` - Form tambah data.
- `daftar.php` - Tabel daftar data.
- `edit.php` - Form edit data.
- `hapus.php` - Proses hapus data.

## Cara Menjalankan di XAMPP

1. Buka aplikasi XAMPP
2. Aktifkan MySQL
3. Pergi ke website, ketik http://localhost/UAS%20Pemrograman%20Web/
4. Tampilan website akan terlihat