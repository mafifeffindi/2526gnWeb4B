<?php
if (!isset($page_title)) {
    $page_title = 'Catatan Keuangan';
}

$active_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?> - Catatan Keuangan</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="site-header">
        <div class="container header-inner">
            <a class="brand" href="index.php">
                <span class="brand-mark">CK</span>
                <span>Catatan Keuangan</span>
            </a>
            <nav class="nav-menu" aria-label="Navigasi utama">
                <a href="index.php" class="<?php echo $active_page === 'index.php' ? 'active' : ''; ?>">Beranda</a>
                <a href="tambah.php" class="<?php echo $active_page === 'tambah.php' ? 'active' : ''; ?>">Tambah Data</a>
                <a href="daftar.php" class="<?php echo in_array($active_page, ['daftar.php', 'edit.php']) ? 'active' : ''; ?>">Daftar Data</a>
            </nav>
        </div>
    </header>
    <main class="main-content">
