<?php
function rupiah($angka)
{
    return 'Rp ' . number_format((float) $angka, 0, ',', '.');
}

function tanggal_indonesia($tanggal)
{
    if (!$tanggal) {
        return '-';
    }

    return date('d M Y', strtotime($tanggal));
}

function bersihkan_input($data)
{
    return trim($data ?? '');
}

function tipe_badge($tipe)
{
    return $tipe === 'pemasukan' ? 'badge badge-income' : 'badge badge-expense';
}
?>
