    </main>
    <footer class="site-footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Catatan Keuangan Sederhana.</p>
        </div>
    </footer>
</body>
</html>
