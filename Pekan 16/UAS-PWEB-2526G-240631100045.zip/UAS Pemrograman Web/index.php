<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

$page_title = 'Beranda';

$summary_query = mysqli_query($conn, "
    SELECT
        COALESCE(SUM(CASE WHEN tipe = 'pemasukan' THEN jumlah ELSE 0 END), 0) AS total_pemasukan,
        COALESCE(SUM(CASE WHEN tipe = 'pengeluaran' THEN jumlah ELSE 0 END), 0) AS total_pengeluaran,
        COUNT(*) AS total_catatan
    FROM catatan_keuangan
");
$summary = mysqli_fetch_assoc($summary_query);
$saldo = $summary['total_pemasukan'] - $summary['total_pengeluaran'];

require_once 'includes/header.php';
?>
<section class="container hero">
    <div class="hero-panel">
        <p class="eyebrow">Sistem catatan keuangan sederhana</p>
        <h1>Kelola pemasukan dan pengeluaran harian.</h1>
        <p class="lead">Website ini dibuat dengan HTML5, CSS, PHP Native, dan MySQL untuk mencatat transaksi keuangan secara sederhana.</p>
        <div class="actions">
            <a class="btn btn-primary" href="tambah.php">Tambah Data</a>
            <a class="btn btn-secondary" href="daftar.php">Lihat Daftar</a>
        </div>
    </div>

    <aside class="summary-panel" aria-label="Ringkasan keuangan">
        <h2>Ringkasan</h2>
        <div class="summary-grid">
            <div class="summary-item">
                <span class="summary-label">Saldo saat ini</span>
                <p class="summary-value"><?php echo rupiah($saldo); ?></p>
            </div>
            <div class="summary-item">
                <span class="summary-label">Total pemasukan</span>
                <p class="summary-value income"><?php echo rupiah($summary['total_pemasukan']); ?></p>
            </div>
            <div class="summary-item">
                <span class="summary-label">Total pengeluaran</span>
                <p class="summary-value expense"><?php echo rupiah($summary['total_pengeluaran']); ?></p>
            </div>
            <div class="summary-item">
                <span class="summary-label">Jumlah catatan</span>
                <p class="summary-value"><?php echo (int) $summary['total_catatan']; ?> data</p>
            </div>
        </div>
    </aside>
</section>

<section class="container section-grid" aria-label="Fitur utama">
    <article class="feature">
        <h3>Tambah Catatan</h3>
        <p>Input tanggal, kategori, tipe transaksi, nominal, dan keterangan.</p>
    </article>
    <article class="feature">
        <h3>Daftar Data</h3>
        <p>Lihat semua catatan pemasukan dan pengeluaran dalam tabel yang mudah dibaca.</p>
    </article>
    <article class="feature">
        <h3>Edit dan Hapus</h3>
        <p>Perbarui data yang salah atau hapus catatan yang tidak dibutuhkan.</p>
    </article>
</section>
<?php require_once 'includes/footer.php'; ?>
