CREATE DATABASE IF NOT EXISTS db_catatan_keuangan
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE db_catatan_keuangan;

CREATE TABLE IF NOT EXISTS catatan_keuangan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATE NOT NULL,
    kategori VARCHAR(100) NOT NULL,
    tipe ENUM('pemasukan', 'pengeluaran') NOT NULL,
    jumlah DECIMAL(12, 2) NOT NULL,
    keterangan TEXT NULL,
    dibuat_pada TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    diperbarui_pada TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO catatan_keuangan (tanggal, kategori, tipe, jumlah, keterangan) VALUES
('2026-06-01', 'Gaji', 'pemasukan', 3500000, 'Gaji bulan Juni'),
('2026-06-03', 'Makan', 'pengeluaran', 45000, 'Makan siang'),
('2026-06-05', 'Transport', 'pengeluaran', 25000, 'Ojek online'),
('2026-06-10', 'Freelance', 'pemasukan', 750000, 'Proyek desain sederhana');
