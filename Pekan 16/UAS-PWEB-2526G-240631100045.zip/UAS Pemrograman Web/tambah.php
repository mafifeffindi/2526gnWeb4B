<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

$page_title = 'Tambah Data';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = bersihkan_input($_POST['tanggal'] ?? '');
    $kategori = bersihkan_input($_POST['kategori'] ?? '');
    $tipe = bersihkan_input($_POST['tipe'] ?? '');
    $jumlah = bersihkan_input($_POST['jumlah'] ?? '');
    $keterangan = bersihkan_input($_POST['keterangan'] ?? '');

    if ($tanggal === '') {
        $errors[] = 'Tanggal wajib diisi.';
    }

    if ($kategori === '') {
        $errors[] = 'Kategori wajib diisi.';
    }

    if (!in_array($tipe, ['pemasukan', 'pengeluaran'], true)) {
        $errors[] = 'Tipe transaksi tidak valid.';
    }

    if (!is_numeric($jumlah) || $jumlah <= 0) {
        $errors[] = 'Jumlah harus berupa angka lebih dari 0.';
    }

    if (!$errors) {
        $stmt = mysqli_prepare($conn, 'INSERT INTO catatan_keuangan (tanggal, kategori, tipe, jumlah, keterangan) VALUES (?, ?, ?, ?, ?)');
        mysqli_stmt_bind_param($stmt, 'sssds', $tanggal, $kategori, $tipe, $jumlah, $keterangan);

        if (mysqli_stmt_execute($stmt)) {
            header('Location: daftar.php?status=tambah-berhasil');
            exit;
        }

        $errors[] = 'Data gagal disimpan.';
    }
}

require_once 'includes/header.php';
?>
<section class="container form-panel">
    <div class="page-heading">
        <div>
            <h1>Tambah Data</h1>
            <p>Masukkan catatan pemasukan atau pengeluaran baru.</p>
        </div>
        <a class="btn btn-secondary" href="daftar.php">Daftar Data</a>
    </div>

    <?php if ($errors): ?>
        <div class="alert alert-error">
            <?php echo htmlspecialchars(implode(' ', $errors)); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="" class="form-grid">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" id="tanggal" name="tanggal"
                value="<?php echo htmlspecialchars($_POST['tanggal'] ?? date('Y-m-d')); ?>" required>
        </div>

        <div class="form-group">
            <label for="kategori">Kategori</label>
            <input type="text" id="kategori" name="kategori" placeholder="Contoh: Gaji, Makan, Transport"
                value="<?php echo htmlspecialchars($_POST['kategori'] ?? ''); ?>" required>
        </div>

        <div class="form-group">
            <label for="tipe">Tipe</label>
            <select id="tipe" name="tipe" required>
                <option value="">Pilih tipe</option>
                <option value="pemasukan" <?php echo (($_POST['tipe'] ?? '') === 'pemasukan') ? 'selected' : ''; ?>>
                    Pemasukan</option>
                <option value="pengeluaran" <?php echo (($_POST['tipe'] ?? '') === 'pengeluaran') ? 'selected' : ''; ?>>
                    Pengeluaran</option>
            </select>
        </div>

        <div class="form-group">
            <label for="jumlah">Jumlah</label>
            <input type="number" id="jumlah" name="jumlah" min="1" step="1" placeholder="Contoh: 50000"
                value="<?php echo htmlspecialchars($_POST['jumlah'] ?? ''); ?>" required>
        </div>

        <div class="form-group full">
            <label for="keterangan">Keterangan</label>
            <textarea id="keterangan" name="keterangan"
                placeholder="Catatan tambahan"><?php echo htmlspecialchars($_POST['keterangan'] ?? ''); ?></textarea>
        </div>

        <div class="form-group full">
            <button type="submit" class="btn btn-primary">Simpan Data</button>
        </div>
    </form>
</section>
<?php require_once 'includes/footer.php'; ?>