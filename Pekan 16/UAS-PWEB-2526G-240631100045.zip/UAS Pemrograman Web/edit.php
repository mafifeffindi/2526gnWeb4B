<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

$page_title = 'Edit Data';
$errors = [];
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($id <= 0) {
    header('Location: daftar.php');
    exit;
}

$stmt = mysqli_prepare($conn, 'SELECT * FROM catatan_keuangan WHERE id = ?');
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    header('Location: daftar.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = bersihkan_input($_POST['tanggal'] ?? '');
    $kategori = bersihkan_input($_POST['kategori'] ?? '');
    $tipe = bersihkan_input($_POST['tipe'] ?? '');
    $jumlah = bersihkan_input($_POST['jumlah'] ?? '');
    $keterangan = bersihkan_input($_POST['keterangan'] ?? '');

    if ($tanggal === '') {
        $errors[] = 'Tanggal wajib diisi.';
    }

    if ($kategori === '') {
        $errors[] = 'Kategori wajib diisi.';
    }

    if (!in_array($tipe, ['pemasukan', 'pengeluaran'], true)) {
        $errors[] = 'Tipe transaksi tidak valid.';
    }

    if (!is_numeric($jumlah) || $jumlah <= 0) {
        $errors[] = 'Jumlah harus berupa angka lebih dari 0.';
    }

    if (!$errors) {
        $update = mysqli_prepare($conn, 'UPDATE catatan_keuangan SET tanggal = ?, kategori = ?, tipe = ?, jumlah = ?, keterangan = ? WHERE id = ?');
        mysqli_stmt_bind_param($update, 'sssdsi', $tanggal, $kategori, $tipe, $jumlah, $keterangan, $id);

        if (mysqli_stmt_execute($update)) {
            header('Location: daftar.php?status=edit-berhasil');
            exit;
        }

        $errors[] = 'Data gagal diperbarui.';
    }

    $data = [
        'tanggal' => $tanggal,
        'kategori' => $kategori,
        'tipe' => $tipe,
        'jumlah' => $jumlah,
        'keterangan' => $keterangan,
    ];
}

require_once 'includes/header.php';
?>
<section class="container form-panel">
    <div class="page-heading">
        <div>
            <h1>Edit Data</h1>
            <p>Perbarui catatan keuangan yang sudah tersimpan.</p>
        </div>
        <a class="btn btn-secondary" href="daftar.php">Kembali</a>
    </div>

    <?php if ($errors): ?>
        <div class="alert alert-error">
            <?php echo htmlspecialchars(implode(' ', $errors)); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="" class="form-grid">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" id="tanggal" name="tanggal" value="<?php echo htmlspecialchars($data['tanggal']); ?>" required>
        </div>

        <div class="form-group">
            <label for="kategori">Kategori</label>
            <input type="text" id="kategori" name="kategori" value="<?php echo htmlspecialchars($data['kategori']); ?>" required>
        </div>

        <div class="form-group">
            <label for="tipe">Tipe</label>
            <select id="tipe" name="tipe" required>
                <option value="pemasukan" <?php echo $data['tipe'] === 'pemasukan' ? 'selected' : ''; ?>>Pemasukan</option>
                <option value="pengeluaran" <?php echo $data['tipe'] === 'pengeluaran' ? 'selected' : ''; ?>>Pengeluaran</option>
            </select>
        </div>

        <div class="form-group">
            <label for="jumlah">Jumlah</label>
            <input type="number" id="jumlah" name="jumlah" min="1" step="100" value="<?php echo htmlspecialchars($data['jumlah']); ?>" required>
        </div>

        <div class="form-group full">
            <label for="keterangan">Keterangan</label>
            <textarea id="keterangan" name="keterangan"><?php echo htmlspecialchars($data['keterangan']); ?></textarea>
        </div>

        <div class="form-group full">
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </div>
    </form>
</section>
<?php require_once 'includes/footer.php'; ?>
