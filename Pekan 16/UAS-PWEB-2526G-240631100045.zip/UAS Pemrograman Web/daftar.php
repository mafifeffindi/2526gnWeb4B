<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

$page_title = 'Daftar Data';
$status = $_GET['status'] ?? '';
$result = mysqli_query($conn, 'SELECT * FROM catatan_keuangan ORDER BY tanggal DESC, id DESC');

require_once 'includes/header.php';
?>
<section class="container content-panel">
    <div class="page-heading">
        <div>
            <h1>Daftar Data</h1>
            <p>Semua catatan keuangan tersimpan di database MySQL.</p>
        </div>
        <a class="btn btn-primary" href="tambah.php">Tambah Data</a>
    </div>

    <?php if ($status === 'tambah-berhasil'): ?>
        <div class="alert alert-success">Data berhasil ditambahkan.</div>
    <?php elseif ($status === 'edit-berhasil'): ?>
        <div class="alert alert-success">Data berhasil diperbarui.</div>
    <?php elseif ($status === 'hapus-berhasil'): ?>
        <div class="alert alert-success">Data berhasil dihapus.</div>
    <?php endif; ?>

    <?php if (mysqli_num_rows($result) > 0): ?>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Kategori</th>
                        <th>Tipe</th>
                        <th>Jumlah</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo tanggal_indonesia($row['tanggal']); ?></td>
                            <td><?php echo htmlspecialchars($row['kategori']); ?></td>
                            <td><span class="<?php echo tipe_badge($row['tipe']); ?>"><?php echo ucfirst($row['tipe']); ?></span></td>
                            <td><?php echo rupiah($row['jumlah']); ?></td>
                            <td><?php echo htmlspecialchars($row['keterangan'] ?: '-'); ?></td>
                            <td>
                                <div class="table-actions">
                                    <a class="btn btn-secondary btn-small" href="edit.php?id=<?php echo (int) $row['id']; ?>">Edit</a>
                                    <a class="btn btn-danger btn-small" href="hapus.php?id=<?php echo (int) $row['id']; ?>" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <h2>Belum ada data</h2>
            <p>Mulai catat pemasukan atau pengeluaran pertama Anda.</p>
            <a class="btn btn-primary" href="tambah.php">Tambah Data</a>
        </div>
    <?php endif; ?>
</section>
<?php require_once 'includes/footer.php'; ?>
